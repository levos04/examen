<?php

include 'conexion.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST['action'];

    switch ($action) {
        // Operaciones para autores
        case 'crear_autor':
            $nombre = $_POST['nombre'];
            $apellido = $_POST['apellido'];
            $fecha_nacimiento = $_POST['fecha_nacimiento'];

            agregar_autor($mysqli, $nombre, $apellido, $fecha_nacimiento);
            break;

        case 'modificar_autor':
            $id_autor = $_POST['id_autor'];
            $nombre = $_POST['nombre'];
            $apellido = $_POST['apellido'];
            $fecha_nacimiento = $_POST['fecha_nacimiento'];

            modificar_autor($mysqli, $id_autor, $nombre, $apellido, $fecha_nacimiento);
            break;

        case 'eliminar_autor':
            $id_autor = $_POST['id_autor'];
            eliminar_autor($mysqli, $id_autor);
            break;

        case 'obtener_autor':
            $id_autor = $_POST['id_autor'];
            obtener_autor($mysqli, $id_autor);
            break;

        // Operaciones para libros
        case 'crear_libro':
            $titulo = $_POST['titulo'];
            $fecha_publicacion = $_POST['fecha_publicacion'];
            $autor_id = $_POST['autor_id'];
            $precio = $_POST['precio'];

            agregar_libro($mysqli, $titulo, $fecha_publicacion, $autor_id, $precio);
            break;

        case 'modificar_libro':
            $id_libro = $_POST['id_libro'];
            $titulo = $_POST['titulo'];
            $fecha_publicacion = $_POST['fecha_publicacion'];
            $autor_id = $_POST['autor_id'];
            $precio = $_POST['precio'];

            modificar_libro($mysqli, $id_libro, $titulo, $fecha_publicacion, $autor_id, $precio);
            break;

        case 'eliminar_libro':
            $id_libro = $_POST['id_libro'];
            eliminar_libro($mysqli, $id_libro);
            break;

        case 'obtener_libros':
            obtener_libros($mysqli);
            break;

        default:
            echo "Operación no válida";
            break;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Biblioteca</title>
    
</head>
<body>
    <div class="container">
        <h2>bienvenido a la Biblioteca!!!!</h2>

        <!-- Formulario para Crear un Autor -->
        <form action="index.php" method="post">
            <input type="hidden" name="action" value="crear_autor">
            <h3>Crear Autor</h3>

            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" required>

            <label for="apellido">Apellido:</label>
            <input type="text" id="apellido" name="apellido" required>

            <label for="fecha_nacimiento">Fecha de Nacimiento:</label>
            <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" required>

            <button type="submit">Crear Autor</button>
        </form>

        <!-- Formulario para Modificar un Autor -->
        <form action="index.php" method="post">
            <input type="hidden" name="action" value="modificar_autor">
            <h3>Modificar Autor</h3>

            <label for="id_autor">ID del Autor:</label>
            <input type="number" id="id_autor" name="id_autor" required>

            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" required>

            <label for="apellido">Apellido:</label>
            <input type="text" id="apellido" name="apellido" required>

            <label for="fecha_nacimiento">Fecha de Nacimiento:</label>
            <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" required>

            <button type="submit">Modificar Autor</button>
        </form>

        <!-- Formulario para Eliminar un Autor -->
        <form action="index.php" method="post">
            <input type="hidden" name="action" value="eliminar_autor">
            <h3>Eliminar Autor</h3>

            <label for="id_autor">ID del Autor:</label>
            <input type="number" id="id_autor" name="id_autor" required>

            <button type="submit">Eliminar Autor</button>
        </form>


        <!-- Formulario para Crear un Libro -->
        <form action="index.php" method="post">
            <input type="hidden" name="action" value="crear_libro">
            <h3>Crear Libro</h3>

            <label for="titulo">Título:</label>
            <input type="text" id="titulo" name="titulo" required>

            <label for="fecha_publicacion">Fecha de Publicación:</label>
            <input type="date" id="fecha_publicacion" name="fecha_publicacion" required>

            <label for="autor_id">ID del Autor:</label>
            <input type="number" id="autor_id" name="autor_id" required>

            <label for="precio">Precio:</label>
            <input type="number" id="precio" name="precio" step="0.01" required>

            <button type="submit">Crear Libro</button>
        </form>

        <!-- Formulario para Modificar un Libro -->
        <form action="index.php" method="post">
            <input type="hidden" name="action" value="modificar_libro">
            <h3>Modificar Libro</h3>

            <label for="id_libro">ID del Libro:</label>
            <input type="number" id="id_libro" name="id_libro" required>

            <label for="titulo">Título:</label>
            <input type="text" id="titulo" name="titulo" required>

            <label for="fecha_publicacion">Fecha de Publicación:</label>
            <input type="date" id="fecha_publicacion" name="fecha_publicacion" required>

            <label for="autor_id">ID del Autor:</label>
            <input type="number" id="autor_id" name="autor_id" required>

            <label for="precio">Precio:</label>
            <input type="number" id="precio" name="precio" step="0.01" required>

            <button type="submit">Modificar Libro</button>
        </form>

        <!-- Formulario para Eliminar un Libro -->
        <form action="index.php" method="post">
            <input type="hidden" name="action" value="eliminar_libro">
            <h3>Eliminar Libro</h3>

            <label for="id_libro">ID del Libro:</label>
            <input type="number" id="id_libro" name="id_libro" required>

            <button type="submit">Eliminar Libro</button>
        </form>

        <!-- Sección para Ver Todos los Autores -->
        <h3>Lista de Autores</h3>
        <?php
        // Mostrar todos los autores
        obtener_autores($mysqli);
        ?>

        <!-- Sección para Ver Todos los Libros -->
        <h3>Lista de Libros</h3>
        <?php
        // Mostrar todos los libros
        obtener_libros($mysqli);
        ?>
    </div>
</body>
</html>