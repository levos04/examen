<?php
$host = 'localhost'; // HostName
$user = 'root'; // Nombre de usuario
$password = ''; // Contraseña
$dbname = 'biblioteca'; // Nombre de la base de datos
$port = 3306; // Puerto (opcional, solo si es diferente de 3306)

// Crear conexión
$mysqli = new mysqli($host, $user, $password, $dbname);

// Verificar conexión
if ($mysqli->connect_error) {
    die('Error de Conexión (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
}


// Funciones para interactuar con la base de datos
// Función para agregar un autor
function agregar_autor($mysqli, $nombre, $apellido, $fecha_nacimiento) {
    $stmt = $mysqli->prepare("CALL agregar_autor(?, ?, ?)");
    $stmt->bind_param("sss", $nombre, $apellido, $fecha_nacimiento);

    if ($stmt->execute()) {
        echo "Autor agregado exitosamente.";
    } else {
        echo "Error al agregar el autor: " . $stmt->error;
    }

    $stmt->close();
}

// Función para eliminar un autor
function eliminar_autor($mysqli, $id) {
    // Eliminar libros asociados al autor
    $stmt = $mysqli->prepare("DELETE FROM libros WHERE autor_id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        // Después de eliminar los libros, eliminar al autor
        $stmt = $mysqli->prepare("DELETE FROM autores WHERE id = ?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            echo "Autor eliminado exitosamente.";
        } else {
            echo "Error al eliminar el autor: " . $stmt->error;
        }
    } else {
        echo "Error al eliminar los libros del autor: " . $stmt->error;
    }

    $stmt->close();
}


// Función para modificar un autor
function modificar_autor($mysqli, $id, $nombre, $apellido, $fecha_nacimiento) {
    $stmt = $mysqli->prepare("CALL modificar_autor(?, ?, ?, ?)");
    $stmt->bind_param("isss", $id, $nombre, $apellido, $fecha_nacimiento);

    if ($stmt->execute()) {
        echo "Autor modificado exitosamente.";
    } else {
        echo "Error al modificar el autor: " . $stmt->error;
    }

    $stmt->close();
}


function obtener_autor($mysqli, $id_autor) {
    $stmt = $mysqli->prepare("SELECT id, nombre, apellido, fecha_nacimiento FROM autores WHERE id_autor = ?");
    $stmt->bind_param("i", $id_autor);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "ID Autor: " . htmlspecialchars($row['id_autor']) . "<br>";
            echo "Nombre: " . htmlspecialchars($row['nombre']) . "<br>";
            echo "Apellido: " . htmlspecialchars($row['apellido']) . "<br>";
            echo "Fecha de Nacimiento: " . htmlspecialchars($row['fecha_nacimiento']) . "<br>";
        }
    } else {
        echo "No se encontró ningún autor con ese ID.";
    }

    $stmt->close();
}

function obtener_autores($mysqli) {
    $result = $mysqli->query("SELECT id, nombre, apellido, fecha_nacimiento FROM autores");
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "ID Autor: " . htmlspecialchars($row['id']) . "<br>";
            echo "Nombre: " . htmlspecialchars($row['nombre']) . "<br>";
            echo "Apellido: " . htmlspecialchars($row['apellido']) . "<br>";
            echo "Fecha de Nacimiento: " . htmlspecialchars($row['fecha_nacimiento']) . "<br><br>";
        }
    } else {
        echo "No se encontraron autores.";
    }
    $result->close();
}




// Función para agregar un libro
function agregar_libro($mysqli, $titulo, $fecha_publicacion, $autor_id, $precio) {
    $stmt = $mysqli->prepare("CALL agregar_libro(?, ?, ?, ?)");
    $stmt->bind_param("ssdi", $titulo, $fecha_publicacion, $autor_id, $precio);

    if ($stmt->execute()) {
        echo "Libro agregado exitosamente.";
    } else {
        echo "Error al agregar el libro: " . $stmt->error;
    }

    $stmt->close();
}

// Función para eliminar un libro
function eliminar_libro($mysqli, $id) {
    $stmt = $mysqli->prepare("CALL eliminar_libro(?)");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "Libro eliminado exitosamente.";
    } else {
        echo "Error al eliminar el libro: " . $stmt->error;
    }

    $stmt->close();
}

// Función para modificar un libro
function modificar_libro($mysqli, $id, $titulo, $fecha_publicacion, $autor_id, $precio) {
    $stmt = $mysqli->prepare("CALL modificar_libro(?, ?, ?, ?, ?)");
    $stmt->bind_param("issdi", $id, $titulo, $fecha_publicacion, $autor_id, $precio);

    if ($stmt->execute()) {
        echo "Libro modificado exitosamente.";
    } else {
        echo "Error al modificar el libro: " . $stmt->error;
    }

    $stmt->close();
}

function obtener_libros($mysqli) {
    $stmt = $mysqli->prepare("CALL obtener_libros()");
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "ID Libro: " . htmlspecialchars($row['id']) . "<br>";
            echo "Título: " . htmlspecialchars($row['titulo']) . "<br>";
            echo "Fecha de Publicación: " . htmlspecialchars($row['fecha_publicacion']) . "<br>";
            echo "ID Autor: " . htmlspecialchars($row['autor_id']) . "<br>";
            echo "Precio: " . htmlspecialchars($row['precio']) . "<br><br>";
        }
    } else {
        echo "No se encontraron libros.";
    }
    $stmt->close();
}



?>